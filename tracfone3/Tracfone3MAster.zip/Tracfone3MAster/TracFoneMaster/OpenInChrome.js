﻿<script type="text/javascript">
  function openURL(link)
  {
      var shell = new ActiveXObject("WScript.Shell");
	var url ="Chrome "+ link;
      	shell.run(url);
  }
  </script>